﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CD_Orders
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEvaluate_Click(object sender, EventArgs e)
        {
            int intQuantity;
            int intTotal = 0;

            intQuantity = Int32.Parse(txtQuantity.Text);
            intTotal = intQuantity * 10;

            txtPrice.Text = intTotal.ToString("C2");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            txtCustomer.Text = "";
            txtQuantity.Text = "";
            txtPrice.Text = "";
        }
    }
}