﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MarineStore
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDataList_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Datalist.aspx");
        }

        protected void btnGridView_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Gridview.aspx");
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Insert.aspx");
        }

        protected void btnSelect_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Select.aspx");
        }
    }
}