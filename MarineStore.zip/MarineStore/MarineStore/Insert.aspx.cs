﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


namespace MarineStore
{
    public partial class Insert : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String sqlConnString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\MarineStoreDB.mdf;Integrated Security=True";
            SqlConnection cn = new SqlConnection(sqlConnString);
            cn.Open();

            String strProductID = txtProductID.Text;
            String strProductName = txtProductName.Text;
            double dblPrice = Convert.ToDouble(txtPrice.Text);
            int intQty = Convert.ToInt32(txtQtyOnHand.Text);
            string strSupplier = txtSupplier.Text;

            String SQL = "Insert into Products (ProductID, ProductName, Price,QtyOnHand,SupplierName) VALUES(@strProductID,@strProductName,@dblPrice,@intQty,@strSupplier)";
            SqlCommand cmd = new SqlCommand(SQL, cn);
            cmd.Parameters.Add(new SqlParameter("@strProductID", strProductID));
            cmd.Parameters.Add(new SqlParameter("@strProductName", strProductName));
            cmd.Parameters.Add(new SqlParameter("@dblPrice", dblPrice));
            cmd.Parameters.Add(new SqlParameter("@intQty", intQty));
            cmd.Parameters.Add(new SqlParameter("@strSupplier", strSupplier));

             int intRowsInserted = cmd.ExecuteNonQuery();

            lblRowsInserted.Text = intRowsInserted.ToString() + " records were inserted";
        }
    }
}