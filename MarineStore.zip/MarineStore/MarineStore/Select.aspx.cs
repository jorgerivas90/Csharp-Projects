﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace MarineStore
{
    public partial class Select : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
          
        }

        protected void btnRecordFind_Click(object sender, EventArgs e)
        {
            String sqlConnString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\MarineStoreDB.mdf;Integrated Security=True";
            SqlConnection cn = new SqlConnection(sqlConnString);
            cn.Open();

            String strProductID = txtProductID.Text;
             
            String SQL = "Select * from Products where productID = @strProductID";
            SqlCommand cmd = new SqlCommand(SQL, cn); 
            cmd.Parameters.Add(new SqlParameter("@strProductID", strProductID));

            SqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.HasRows)
            {
                while (rdr.Read())
                {
                    lblProductName.Text = rdr.GetString(1);
                }
            }
            else
            {
                lblProductName.Text = "Product not found in a database";
            }
        } 
    }
}