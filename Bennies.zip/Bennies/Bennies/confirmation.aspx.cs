﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bennies.Models;

namespace Bennies
{
    public partial class confirmation : System.Web.UI.Page
    {

        private JobApplicationData jobApplication = new JobApplicationData();
        protected void Page_Load(object sender, EventArgs e)
        {
            jobApplication =(JobApplicationData) Session["ApplicantData"];
            lblName.Text = "Name: " + jobApplication.name;
            lblPhone.Text = "Phone: " + jobApplication.phone;
            lblEducationLevel.Text = "Education Level: " + jobApplication.educationlevel;
            lblShift.Text = "Work Hours: " + jobApplication.shift;

        }
    }
}