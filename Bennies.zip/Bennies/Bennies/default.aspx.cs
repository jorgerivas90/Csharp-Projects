﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bennies.Models;


namespace Bennies
{
    public partial class _default : System.Web.UI.Page
    {
        private JobApplicationData jobApplication = new JobApplicationData();
        protected void Page_Load(object sender, EventArgs e)
        {
            rblPreferredShift.Items.Add("Morning");
            rblPreferredShift.Items.Add("Afternnon");
            rblPreferredShift.Items.Add("Evening");
        }

        protected void btnApply_Click(object sender, EventArgs e)
        {
            jobApplication.name = txtName.Text;
            jobApplication.phone = txtPhone.Text;
            jobApplication.educationlevel = ddlEducationLevel.SelectedValue;
            jobApplication.shift = rblPreferredShift.SelectedValue;
            Session["ApplicantData"] = jobApplication;
            Response.Redirect("confirmation.aspx");
        }
    }
}