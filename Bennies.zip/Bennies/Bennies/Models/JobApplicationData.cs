﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Bennies.Models
{
    public class JobApplicationData
    {
        public String name { get; set; }
        public String phone { get; set; }
        public string educationlevel { get; set; }
        public string shift { get; set; }





    }
}