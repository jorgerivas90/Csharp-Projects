﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TravelDestination1
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLasVegas_Click(object sender, EventArgs e)
        {
            lblBookingMessage.Text = "Your vacation to Las Vegas for $500 is booked";
            imgDestination.ImageUrl = "../Images/LasVegasNevada.jpg";
        }

        protected void btnMiami_Click(object sender, EventArgs e)
        {
            lblBookingMessage.Text = "Your vacation to Miami for $1,500 is booked";
            imgDestination.ImageUrl = "../Images/MiamiFlorida.jpg";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblBookingMessage.Text = "Your vacation to New York for $1,000 is booked";
            imgDestination.ImageUrl = "../Images/ManhattanNewYork.jpg";
        }
    }
} 