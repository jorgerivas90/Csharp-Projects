﻿CREATE TABLE [dbo].[Supplier]
(
	[SupplierID] INT NOT NULL PRIMARY KEY
)
