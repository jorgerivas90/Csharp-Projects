﻿CREATE TABLE [dbo].[Product]
(
	[ProductID] CHAR(10) NOT NULL PRIMARY KEY, 
    [Product Name] NCHAR(10) NOT NULL, 
    [Price] MONEY NOT NULL, 
    [Quantity on Hand] INT NOT NULL
)
