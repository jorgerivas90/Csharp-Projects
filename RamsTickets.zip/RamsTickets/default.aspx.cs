﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RamsTickets
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCalc_Click(object sender, EventArgs e)
        {
            int intResult = 0;
            int intNum1 = 0;
            intNum1 = Int32.Parse(txtNumberOfTickets.Text);
            intResult = intNum1 * 100;
            lblMessage.Text = "Great decision! Your cost is $" + intResult.ToString();
            
        }
    }
}