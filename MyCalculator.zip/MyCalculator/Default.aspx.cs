﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MyCalculator
{
    public partial class Default : System.Web.UI.Page
    {
        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            int intResult = 0;
            int intNum1 = 0;
            int intNum2 = 0;
            intNum1 = Int32.Parse(txtFirstNumber.Text);
            intNum2 = Int32.Parse(txtSecondNumber.Text);
            if (rbOperation.SelectedValue == "A")
            {
                intResult = intNum1 + intNum2;
            }
            if (rbOperation.SelectedValue == "S")
            {
                intResult = intNum1 - intNum2;
            }
            if (rbOperation.SelectedValue == "M")
            {
                intResult = intNum1 * intNum2;
            }
            if (rbOperation.SelectedValue == "D")
            {
                intResult = intNum1 / intNum2;
            }
            lblResult.Text = intResult.ToString();

        }
    }
}