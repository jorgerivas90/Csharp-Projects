﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SportsArray
{
  
    public partial class _default : System.Web.UI.Page
    {
        string[] strSportsList = { "Tennis", "Sailing", "Rugby", "Soccer", "Football" };


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int intIndex = int.Parse(txtNumber.Text);

            if (intIndex < 1 || intIndex > 5)
            {
                lblDisplay.Text = "Please Enter a number between 1 and 5 in the text box";
            }
            else
            {
                intIndex = intIndex - 1;
                lblDisplay.Text = strSportsList[intIndex];
            }
        }
    }
}