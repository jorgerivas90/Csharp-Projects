﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Ch08Cart
{
    public partial class CheckOut : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            // {
            //     if (!(Request.Cookies["FirstName"] == null))
            //         txtFirstName.Text = Request.Cookies["FirstName"].Value;

            //     if (!(Request.Cookies["LastName"] == null))
            //         txtLastName.Text = Request.Cookies["LastName"].Value;

            // }

            if (!IsPostBack)
            {
                if (Session["FirstName"] == null && Session["LastName"] == null)
                {
                    Session["FirstName"] = txtFirstName.Text;
                    Session["LastName"] = txtLastName.Text;
                }
                else
                {
                    txtFirstName.Text = Session["FirstName"].ToString();
                    txtLastName.Text = Session["LastName"].ToString();
                }

                
            }
        }

        protected void btnContinue_Click(object sender, EventArgs e)
        {
            //if (IsValid)
            //{
            //   DateTime expiry = DateTime.Now.AddMinutes(5);
            //   SetCookie("FirstName", txtFirstName.Text, expiry);
            //   SetCookie("LastName", txtLastName.Text, expiry);
            // }

            Session["FirstName"] = txtFirstName.Text;
            Session["LastName"] = txtLastName.Text;

            Response.Redirect("~/Order.aspx");
            

        }

        private void SetCookie(string name, string value, DateTime expiry)
        {
            HttpCookie cookie = new HttpCookie(name, value);
            cookie.Expires = expiry;
            Response.Cookies.Add(cookie);
        }

    }
}