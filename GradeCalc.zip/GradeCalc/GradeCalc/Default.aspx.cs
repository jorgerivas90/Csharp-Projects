﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace GradeCalc
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCalc_Click(object sender, EventArgs e)
        {
            int intGrade = int.Parse(txtNumericalGrade.Text);

            if (intGrade >= 88)
            {
                lblLetterGrade.Text = "Your grade is an A";
            }
            else if (intGrade >= 80)
            {
                lblLetterGrade.Text = "Your grade is an B";
            }
            else if (intGrade >= 68)
            {
                lblLetterGrade.Text = "Your grade is an C";
            }
            else if (intGrade >= 60)
            {
                lblLetterGrade.Text = "Your grade is an D";
            }
            else if (intGrade <= 69)
            {
                lblLetterGrade.Text = "Your grade is an F";
            }
        }
    }
}